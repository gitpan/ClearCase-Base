===============
ClearCase::Base
===============

Copyright (c) 2004 Mauro Ribeiro (mribeiro@cpqd.com.br).
All rights reserved. This program is free software; you can redistribute
it and/or modify it under the same terms as Perl itself.

DESCRIPTION
-----------

This distribution is just a upload test, please do not use it. 
This module is under construction yet.

VERSION
-------
This is module version 0.01
